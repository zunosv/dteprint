# ============================================================
#  GrupoRVQ — Escaner de QR codes DTE
#  Escanea Z:\sistemas\sicgas\Iconos\qr\ y exporta un JSON
#  con codGeneracion y fecEmi de cada archivo PNG
# ============================================================

param(
    [string]$CarpetaQR  = "Z:\sistemas\sicgas\Iconos\qr",
    [string]$Salida      = "$PSScriptRoot\dte_index.json"
)

Write-Host ""
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  GrupoRVQ - Escaner DTE QR" -ForegroundColor Cyan
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""

# Verificar que la carpeta existe
if (-not (Test-Path $CarpetaQR)) {
    Write-Host "ERROR: No se encuentra la carpeta: $CarpetaQR" -ForegroundColor Red
    Write-Host "Verifica que la unidad Z: este conectada." -ForegroundColor Yellow
    Read-Host "Presiona Enter para salir"
    exit 1
}

Write-Host "Escaneando: $CarpetaQR" -ForegroundColor Green
Write-Host ""

# Obtener todos los PNG
$archivos = Get-ChildItem -Path $CarpetaQR -Filter "*.png" -File

$total = $archivos.Count
Write-Host "Archivos encontrados: $total" -ForegroundColor Yellow
Write-Host ""

if ($total -eq 0) {
    Write-Host "No se encontraron archivos PNG." -ForegroundColor Red
    Read-Host "Presiona Enter para salir"
    exit 1
}

# Construir lista
$lista = @()
$i = 0

foreach ($archivo in $archivos) {
    $i++

    # Código de generación = nombre sin extensión
    $codGeneracion = [System.IO.Path]::GetFileNameWithoutExtension($archivo.Name).ToUpper()

    # Fecha de creación formateada como yyyy-MM-dd
    $fecEmi = $archivo.CreationTime.ToString("yyyy-MM-dd")

    $lista += [PSCustomObject]@{
        codGeneracion = $codGeneracion
        fecEmi        = $fecEmi
        archivo       = $archivo.Name
    }

    # Progreso cada 100
    if ($i % 100 -eq 0 -or $i -eq $total) {
        $pct = [math]::Round(($i / $total) * 100)
        Write-Host "  Procesados: $i / $total ($pct%)" -ForegroundColor Gray
    }
}

# Exportar a JSON
Write-Host ""
Write-Host "Exportando JSON a: $Salida" -ForegroundColor Green

$json = $lista | ConvertTo-Json -Depth 3

# Con encabezado para que el HTML lo pueda leer
$output = @{
    generado = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    total    = $total
    registros = $lista
} | ConvertTo-Json -Depth 4

$output | Out-File -FilePath $Salida -Encoding UTF8

Write-Host ""
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  LISTO: $total registros exportados" -ForegroundColor Green
Write-Host "  Archivo: $Salida" -ForegroundColor Green
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Ahora abre dte-qr-database.html en el navegador." -ForegroundColor Yellow
Write-Host ""
Read-Host "Presiona Enter para cerrar"
